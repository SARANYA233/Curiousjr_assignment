$(document).ready(function () {
  $("#runBtn").click(function () {
    runcode();
  });
  $("#resetBtn").click(function () {
    reset();
  });
});

Blockly.Blocks["Bot"] = {  // changed : example_input_text
  init: function () {
    this.appendStatementInput("Bot")
            .setCheck(null)
    this.appendDummyInput()
      .appendField("Bot")
      /*.appendField(new Blockly.FieldInputText("write here..."), "input");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null); */
    this.setColour(230);
    this.setTooltip("");
    this.setHelpUrl("");
  },
};

// Added block 
Blockly.Blocks['ask_me_a_question'] = {
  init: function() {
      this.appendDummyInput()
          .appendField("Ask me a question")
          .appendField(new Blockly.FieldDropdown([
              ["What is the date today?", "a"],
              ["What is the time now?", "b"],
              ["How are you?", "c"],
              ["What is JavaScript?", "d"],
              ["What is your name?", "e"]
          ]), "Ask a Question");
      this.setPreviousStatement(true, null);
     // this.setNextStatement(true, null);
      this.setColour(165);
      this.setTooltip("");
      this.setHelpUrl("");
  }
};

Blockly.JavaScript['Bot'] = function(block) {
  //boxText = "";
  //code = '';
  var statements_bot = Blockly.JavaScript.statementToCode(block, 'Bot').trim();
  //code += statements_bot;
  //console.log(statements_bot);
  var code = `
    var inputTextValue = "${statements_bot}";
`;
  return code;
};

Blockly.JavaScript['ask_me_a_question'] = function(block) {
  return block.getFieldValue('Ask a Question');
  //var dropdown_ask_me_a_question = block.getFieldValue('Ask me a Question');
  //return bot(dropdown_ask_me_a_question);
};

function redrawUi() {
  let text;
  if (typeof inputTextValue !== "undefined") {

    switch (inputTextValue) {
      case "a":
        var today = new Date();
        text = "The Date is " + new Date().toLocaleDateString();
        break;
      case "b":
        var today = new Date();
        text = "The Time is " + new Date().toLocaleTimeString();
        break;
      case "c":
        text = "I am fine :)";
        break;
      case "d":
        text = "JavaScript is a lightweight, interpreted programming language. It is designed for creating network-centric applications. It is complimentary to and integrated with Java. JavaScript is very easy to implement because it is integrated with HTML. It is open and cross-platform.";
        break;
      case "e":
        text = "I am Bot.";
        break;
      default:
        text = "Ask me smthg..!!";
    }
    console.log(text);
    $("#inputBox").text(text);
    
  } else {
    $("#inputBox").text("");
  }
}
/*
function bot(dropdown_ask_me_a_question) {
  let code = "";
  if (dropdown_ask_me_a_question === "a") {
      code = `boxText += "The date is: " + new Date().toLocaleDateString();`
  } else if (dropdown_ask_me_a_question === "b") {
      code = `boxText += "The time is: " + new Date().toLocaleTimeString();`
  } else if (dropdown_ask_me_a_question === "c") {
      code = `boxText += "I am fine :)";`
  } else if (dropdown_ask_me_a_question === "d") {
      code = `boxText += "JavaScript is a lightweight, interpreted programming language. It is designed for creating network-centric applications. It is complimentary to and integrated with Java. JavaScript is very easy to implement because it is integrated with HTML. It is open and cross-platform.";`
  } else if (dropdown_ask_me_a_question === "e") {
      code = `boxText += "I am Bot.";`
  }
  code += `\nboxText += "<br><br>";\n`
  return code;
}
*/
/*
Blockly.JavaScript["example_input_text"] = function (block) {
  var text_input = block.getFieldValue("input");

  var code = `
	var inputTextValue = "${text_input}";
  `;
  return code;
};
*/
var workspace = Blockly.inject("blocklyDiv", {
  media: "assets/media/",
  toolbox: document.getElementById("toolbox"),
});
/*
function redrawUi() {
  if (typeof boxText !== "undefined") { //changed: inputTextValue
    $("#inputBox").html(boxText); // changed: html
  } else {
    $("#inputBox").html("");
  }
}
*/
/*
function runcode() {
  try {
      code = '';
      eval(Blockly.JavaScript.workspaceToCode(workspace));
  } catch (e) {
      console.error(e);
  }
  redrawUi();
}
*/

function runcode() {
  // Generate JavaScript code and run it.
  var geval = eval;
  try {
    geval(Blockly.JavaScript.workspaceToCode(workspace));
  } catch (e) {
    console.error(e);
  }
  redrawUi();
}


function reset() {
  delete inputTextValue;
 // delete boxText;
  location.reload();
  redrawUi();
 // Blockly.mainWorkspace.clear();
}
